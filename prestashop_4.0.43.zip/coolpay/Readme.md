# CoolPay

## About

Accept payments via CoolPay payment gateway.
